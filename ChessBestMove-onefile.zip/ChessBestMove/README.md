# ChessBestMove

Aplicativo desktop para Windows, com interface em Python/Tkinter e o motor Stockfish para sugerir lances fortes, analisar posições e jogar uma partida.

## Recursos

- Tabuleiro interativo com validação de lances legais.
- Jogo contra o Stockfish escolhendo jogar de brancas ou pretas.
- Modo de análise livre, em que o usuário pode jogar pelos dois lados.
- Sugestão do melhor lance, avaliação numérica e até três variantes principais.
- Profundidade configurável entre 8 e 30 plies.
- Carregamento de uma posição via FEN.
- Desfazer lances e exportar a partida em PGN.

## Dependências e projetos de código aberto

- `python-chess` (regras, PGN e comunicação UCI): https://github.com/niklasf/python-chess
- `Stockfish` (motor de xadrez): https://github.com/official-stockfish/Stockfish
- Stockfish downloads: https://stockfishchess.org/download/

O binário do Stockfish não é armazenado no repositório. Para instalar automaticamente a versão universal oficial para Windows x86-64, abra o PowerShell nesta pasta e execute `powershell -ExecutionPolicy Bypass -File .\download_stockfish.ps1`. O script baixa o ZIP diretamente da página oficial de releases do Stockfish e guarda `stockfish.exe` e eventuais arquivos `.nnue` em `engine/`. Também é possível baixar manualmente em https://stockfishchess.org/download/.

Para detecção automática, o executável fica em `engine/stockfish.exe` (ao lado de `main.py`) e, na compilação local, o `build_windows.bat` o copia para `dist/ChessBestMove/engine/` quando já foi baixado. Também é possível clicar em **Selecionar Stockfish** e indicar o arquivo manualmente.

## Executar pelo código-fonte

Instale Python 3.11 ou 3.12 de 64 bits. Abra um terminal nesta pasta e execute:

```powershell
py -3 -m venv .venv
.venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
python main.py
```

## Gerar o `.exe` no Windows

Dê dois cliques em `build_windows.bat`. O PyInstaller criará uma distribuição em `dist/ChessBestMove/`. Para rodar, abra `ChessBestMove.exe`. A pasta inteira precisa ser mantida; o aplicativo não foi configurado como executável único (one-file) para facilitar o diagnóstico e a inclusão do motor.

Se o motor não estiver no caminho padrão, escolha-o no próprio aplicativo. O `.exe` do aplicativo e o executável Stockfish são componentes separados.

## Gerar o `.exe` usando GitHub Actions

1. Crie um repositório no GitHub e envie estes arquivos.
2. Abra a aba **Actions** e permita a execução dos workflows, se o GitHub solicitar.
3. Execute o workflow **Build Windows EXE** (ou envie um novo commit).
4. Baixe o artefato `ChessBestMove-Windows` ao final da execução.

O workflow constrói o programa em um runner Windows real. O artefato inclui o aplicativo compilado, mas não o motor Stockfish. Execute `download_stockfish.ps1` antes de compilar localmente, ou baixe o motor pelo site oficial e coloque-o em `engine/stockfish.exe` dentro da pasta de saída. Os arquivos `.nnue`, se presentes no ZIP, devem ficar na mesma pasta.

## Observações

- A profundidade maior normalmente demora mais e usa mais CPU. Comece em 10–12.
- A avaliação é mostrada do ponto de vista das brancas: `+1.00` favorece as brancas e `-1.00` favorece as pretas. Valores de mate são mostrados como mate.
- Stockfish é um programa independente distribuído sob GPL-3.0. Consulte os termos e avisos no repositório oficial antes de redistribuir o motor.
- Este projeto usa a biblioteca `python-chess`; veja seus termos no repositório original.
