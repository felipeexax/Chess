from __future__ import annotations

import os
import sys
import threading
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox, simpledialog, ttk

try:
    import chess
    import chess.engine
    import chess.pgn
except ImportError as exc:
    raise SystemExit(
        "Biblioteca ausente. Execute 'python -m pip install -r requirements.txt' e tente novamente."
    ) from exc

APP_NAME = "ChessBestMove"
BOARD_SIZE = 560
SQUARE_SIZE = BOARD_SIZE // 8
PIECES = {
    chess.WHITE: {
        chess.KING: "♔", chess.QUEEN: "♕", chess.ROOK: "♖",
        chess.BISHOP: "♗", chess.KNIGHT: "♘", chess.PAWN: "♙",
    },
    chess.BLACK: {
        chess.KING: "♚", chess.QUEEN: "♛", chess.ROOK: "♜",
        chess.BISHOP: "♝", chess.KNIGHT: "♞", chess.PAWN: "♟",
    },
}
LIGHT_SQUARE = "#f0d9b5"
DARK_SQUARE = "#b58863"
LAST_MOVE = "#c9d56b"
SELECTED = "#f6e96b"
LEGAL_DOT = "#2e7d4f"


def application_dir() -> Path:
    """Folder containing the script or frozen executable."""
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent


class ChessBestMoveApp:
    def __init__(self, root: tk.Tk) -> None:
        self.root = root
        self.root.title("ChessBestMove — análise de xadrez")
        self.root.minsize(960, 650)
        self.root.geometry("1120x760")
        self.root.configure(bg="#171a21")

        self.board = chess.Board()
        self.start_board = self.board.copy(stack=False)
        self.selected_square: chess.Square | None = None
        self.legal_targets: set[chess.Square] = set()
        self.last_move: chess.Move | None = None
        self.engine: chess.engine.SimpleEngine | None = None
        self.engine_path: Path | None = self._find_engine()
        self.busy = False
        self.request_id = 0
        self.best_move: chess.Move | None = None
        self.best_move_text = ""
        self.side_var = tk.StringVar(value="Brancas")
        self.mode_var = tk.StringVar(value="Jogar contra Stockfish")
        self.depth_var = tk.IntVar(value=12)
        self.status_var = tk.StringVar(value="Pronto. Faça um lance ou peça uma análise.")
        self.eval_var = tk.StringVar(value="Avaliação: —")
        self.best_var = tk.StringVar(value="Melhor lance: —")
        self.analysis_var = tk.StringVar(value="Linhas de análise aparecerão aqui.")
        self.move_var = tk.StringVar(value="Nenhum lance ainda.")

        self._build_ui()
        self._render_board()
        self._refresh_move_list()
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)
        if self.engine_path:
            self.status_var.set(f"Stockfish localizado: {self.engine_path.name}")
        else:
            self.status_var.set("Stockfish não localizado. Clique em 'Selecionar Stockfish'.")

    def _find_engine(self) -> Path | None:
        base = application_dir()
        names = (
            "stockfish.exe", "stockfish-windows-x86-64-avx2.exe",
            "stockfish-windows-x86-64.exe", "stockfish",
        )
        for folder in (base / "engine", base):
            for name in names:
                candidate = folder / name
                if candidate.is_file():
                    return candidate
        return None

    def _build_ui(self) -> None:
        style = ttk.Style()
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure("TFrame", background="#171a21")
        style.configure("Panel.TFrame", background="#222733")
        style.configure("TLabel", background="#171a21", foreground="#f4f5f7", font=("Segoe UI", 10))
        style.configure("Panel.TLabel", background="#222733", foreground="#f4f5f7", font=("Segoe UI", 10))
        style.configure("Title.TLabel", background="#171a21", foreground="#ffffff", font=("Segoe UI", 17, "bold"))
        style.configure("TButton", font=("Segoe UI", 10), padding=7)
        style.configure("TCombobox", padding=5)
        style.configure("TSpinbox", padding=4)

        outer = ttk.Frame(self.root, padding=14)
        outer.pack(fill="both", expand=True)
        ttk.Label(outer, text="CHESS BEST MOVE", style="Title.TLabel").pack(anchor="w", pady=(0, 10))

        main = ttk.Frame(outer)
        main.pack(fill="both", expand=True)
        left = ttk.Frame(main)
        left.pack(side="left", fill="y", padx=(0, 16))
        right = ttk.Frame(main, style="Panel.TFrame", padding=14)
        right.pack(side="left", fill="both", expand=True)

        self.canvas = tk.Canvas(
            left, width=BOARD_SIZE, height=BOARD_SIZE,
            background=DARK_SQUARE, highlightthickness=0, borderwidth=0,
        )
        self.canvas.pack()
        self.canvas.bind("<Button-1>", self._on_board_click)
        ttk.Label(left, text="Dica: clique em uma peça e depois na casa de destino.").pack(anchor="w", pady=(8, 0))

        ttk.Label(right, text="Partida e motor", style="Panel.TLabel", font=("Segoe UI", 12, "bold")).pack(anchor="w", pady=(0, 8))
        setting_row = ttk.Frame(right, style="Panel.TFrame")
        setting_row.pack(fill="x", pady=(0, 8))
        ttk.Label(setting_row, text="Modo", style="Panel.TLabel").grid(row=0, column=0, sticky="w", padx=(0, 8), pady=3)
        self.mode_combo = ttk.Combobox(setting_row, textvariable=self.mode_var, values=("Jogar contra Stockfish", "Analisar livre"), state="readonly", width=23)
        self.mode_combo.grid(row=0, column=1, sticky="ew", pady=3)
        self.mode_combo.bind("<<ComboboxSelected>>", self._mode_changed)
        ttk.Label(setting_row, text="Você joga de", style="Panel.TLabel").grid(row=1, column=0, sticky="w", padx=(0, 8), pady=3)
        self.side_combo = ttk.Combobox(setting_row, textvariable=self.side_var, values=("Brancas", "Pretas"), state="readonly", width=23)
        self.side_combo.grid(row=1, column=1, sticky="ew", pady=3)
        self.side_combo.bind("<<ComboboxSelected>>", self._side_changed)
        ttk.Label(setting_row, text="Profundidade", style="Panel.TLabel").grid(row=2, column=0, sticky="w", padx=(0, 8), pady=3)
        self.depth_spin = ttk.Spinbox(setting_row, from_=8, to=30, increment=1, textvariable=self.depth_var, width=8)
        self.depth_spin.grid(row=2, column=1, sticky="w", pady=3)
        setting_row.columnconfigure(1, weight=1)

        buttons = ttk.Frame(right, style="Panel.TFrame")
        buttons.pack(fill="x", pady=(0, 10))
        self.action_buttons = []
        for label, command, grid_opts in (
            ("Nova partida", self.new_game, {"row": 0, "column": 0, "sticky": "ew", "padx": (0, 5), "pady": 3}),
            ("Melhor lance", self.analyse_position, {"row": 0, "column": 1, "sticky": "ew", "padx": 5, "pady": 3}),
            ("Jogar lance", self.play_best_move, {"row": 0, "column": 2, "sticky": "ew", "padx": (5, 0), "pady": 3}),
            ("Voltar", self.undo_move, {"row": 1, "column": 0, "sticky": "ew", "padx": (0, 5), "pady": 3}),
            ("Abrir FEN", self.load_fen, {"row": 1, "column": 1, "sticky": "ew", "padx": 5, "pady": 3}),
            ("Exportar PGN", self.export_pgn, {"row": 1, "column": 2, "sticky": "ew", "padx": (5, 0), "pady": 3}),
        ):
            button = self._button(buttons, label, command)
            button.grid(**grid_opts)
            self.action_buttons.append(button)
        engine_button = self._button(buttons, "Selecionar Stockfish", self.choose_engine)
        engine_button.grid(row=2, column=0, columnspan=3, sticky="ew", pady=3)
        self.action_buttons.append(engine_button)
        for col in range(3):
            buttons.columnconfigure(col, weight=1)

        ttk.Separator(right).pack(fill="x", pady=8)
        ttk.Label(right, textvariable=self.status_var, style="Panel.TLabel", wraplength=440).pack(anchor="w", pady=(0, 8))
        ttk.Label(right, textvariable=self.eval_var, style="Panel.TLabel", font=("Segoe UI", 11, "bold")).pack(anchor="w", pady=2)
        ttk.Label(right, textvariable=self.best_var, style="Panel.TLabel", font=("Segoe UI", 11, "bold"), wraplength=440).pack(anchor="w", pady=2)
        ttk.Label(right, text="Principais variantes", style="Panel.TLabel", font=("Segoe UI", 11, "bold")).pack(anchor="w", pady=(12, 4))
        self.analysis_text = tk.Text(right, height=7, wrap="word", bg="#171a21", fg="#edf0f5", insertbackground="white", relief="flat", font=("Consolas", 10), padx=8, pady=8)
        self.analysis_text.pack(fill="x", pady=(0, 10))
        self.analysis_text.insert("1.0", "Clique em 'Melhor lance' para analisar a posição atual.\n")
        self.analysis_text.configure(state="disabled")
        ttk.Label(right, text="Lances da partida", style="Panel.TLabel", font=("Segoe UI", 11, "bold")).pack(anchor="w", pady=(0, 4))
        self.moves_text = tk.Text(right, height=8, wrap="word", bg="#171a21", fg="#edf0f5", insertbackground="white", relief="flat", font=("Consolas", 10), padx=8, pady=8)
        self.moves_text.pack(fill="both", expand=True)
        self.moves_text.configure(state="disabled")
        ttk.Label(outer, textvariable=self.move_var).pack(anchor="w", pady=(8, 0))

    @staticmethod
    def _button(parent: ttk.Frame, text: str, command) -> ttk.Button:
        return ttk.Button(parent, text=text, command=command)

    def _set_analysis_text(self, text: str) -> None:
        self.analysis_text.configure(state="normal")
        self.analysis_text.delete("1.0", "end")
        self.analysis_text.insert("1.0", text)
        self.analysis_text.configure(state="disabled")

    def _side_to_move_text(self) -> str:
        if self.board.is_checkmate():
            return "Xeque-mate. " + ("Pretas venceram." if self.board.turn == chess.WHITE else "Brancas venceram.")
        if self.board.is_stalemate():
            return "Empate por afogamento."
        if self.board.is_insufficient_material():
            return "Empate por material insuficiente."
        turn = "Brancas" if self.board.turn == chess.WHITE else "Pretas"
        return f"Vez das {turn.lower()}" + (" — xeque!" if self.board.is_check() else ".")

    def _render_board(self) -> None:
        self.canvas.delete("all")
        targets = self.legal_targets if self.selected_square is not None else set()
        for rank in range(8):
            for file_index in range(8):
                square = chess.square(file_index, 7 - rank)
                x0, y0 = file_index * SQUARE_SIZE, rank * SQUARE_SIZE
                x1, y1 = x0 + SQUARE_SIZE, y0 + SQUARE_SIZE
                color = LIGHT_SQUARE if (rank + file_index) % 2 == 0 else DARK_SQUARE
                if self.last_move and square in (self.last_move.from_square, self.last_move.to_square):
                    color = LAST_MOVE
                if self.selected_square == square:
                    color = SELECTED
                self.canvas.create_rectangle(x0, y0, x1, y1, fill=color, outline=color)

                piece = self.board.piece_at(square)
                if piece:
                    glyph = PIECES[piece.color][piece.piece_type]
                    fg = "#fffdf4" if piece.color == chess.WHITE else "#171717"
                    outline = "#262626" if piece.color == chess.WHITE else "#f5eee2"
                    cx, cy = x0 + SQUARE_SIZE / 2, y0 + SQUARE_SIZE / 2 + 1
                    # A subtle outline improves contrast on both square colors.
                    self.canvas.create_text(cx + 1, cy + 1, text=glyph, fill=outline, font=("Segoe UI Symbol", 43, "bold"))
                    self.canvas.create_text(cx, cy, text=glyph, fill=fg, font=("Segoe UI Symbol", 43, "bold"))
                if square in targets:
                    cx, cy = x0 + SQUARE_SIZE / 2, y0 + SQUARE_SIZE / 2
                    if self.board.piece_at(square):
                        self.canvas.create_oval(x0 + 4, y0 + 4, x1 - 4, y1 - 4, outline=LEGAL_DOT, width=4)
                    else:
                        radius = 8
                        self.canvas.create_oval(cx - radius, cy - radius, cx + radius, cy + radius, fill=LEGAL_DOT, outline="")
                if file_index == 0:
                    self.canvas.create_text(x0 + 7, y0 + 7, text=str(8 - rank), fill="#3d3023", anchor="nw", font=("Segoe UI", 8, "bold"))
                if rank == 7:
                    self.canvas.create_text(x1 - 7, y1 - 7, text=chess.FILE_NAMES[file_index], fill="#3d3023", anchor="se", font=("Segoe UI", 8, "bold"))

        if self.best_move and self.best_move in self.board.legal_moves:
            fx = chess.square_file(self.best_move.from_square) * SQUARE_SIZE + SQUARE_SIZE / 2
            fy = (7 - chess.square_rank(self.best_move.from_square)) * SQUARE_SIZE + SQUARE_SIZE / 2
            tx = chess.square_file(self.best_move.to_square) * SQUARE_SIZE + SQUARE_SIZE / 2
            ty = (7 - chess.square_rank(self.best_move.to_square)) * SQUARE_SIZE + SQUARE_SIZE / 2
            self.canvas.create_line(fx, fy, tx, ty, fill="#2f80ed", width=5, arrow=tk.LAST, arrowshape=(16, 18, 7), tags="best_arrow")

    def _on_board_click(self, event: tk.Event) -> None:
        if self.busy or self.board.is_game_over(claim_draw=True):
            return
        file_index = int(event.x // SQUARE_SIZE)
        rank_index = 7 - int(event.y // SQUARE_SIZE)
        if not (0 <= file_index < 8 and 0 <= rank_index < 8):
            return
        square = chess.square(file_index, rank_index)

        if self.selected_square is not None and square in self.legal_targets:
            move = self._choose_move(self.selected_square, square)
            if move:
                self._push_move(move, source="human")
            return

        if self.mode_var.get() == "Jogar contra Stockfish":
            human_color = chess.WHITE if self.side_var.get() == "Brancas" else chess.BLACK
            if self.board.turn != human_color:
                self.status_var.set("É a vez do Stockfish. Aguarde a resposta do motor.")
                return

        piece = self.board.piece_at(square)
        if piece and piece.color == self.board.turn:
            self.selected_square = square
            self.legal_targets = {m.to_square for m in self.board.legal_moves if m.from_square == square}
            self.status_var.set(f"Selecionada: {chess.square_name(square)}. Escolha uma casa destacada.")
        else:
            self.selected_square = None
            self.legal_targets = set()
            self.status_var.set(self._side_to_move_text())
        self._render_board()

    def _choose_move(self, from_square: chess.Square, to_square: chess.Square) -> chess.Move | None:
        candidates = [m for m in self.board.legal_moves if m.from_square == from_square and m.to_square == to_square]
        if not candidates:
            return None
        if len(candidates) == 1:
            return candidates[0]
        choices = (("Dama", chess.QUEEN), ("Torre", chess.ROOK), ("Bispo", chess.BISHOP), ("Cavalo", chess.KNIGHT))
        dialog = tk.Toplevel(self.root)
        dialog.title("Promoção de peão")
        dialog.transient(self.root)
        dialog.grab_set()
        ttk.Label(dialog, text="Escolha a peça para promoção:", padding=10).pack()
        selected: list[chess.Move | None] = [None]
        row = ttk.Frame(dialog, padding=(8, 0, 8, 8))
        row.pack()
        for label, piece_type in choices:
            matching = next((m for m in candidates if m.promotion == piece_type), None)
            if matching:
                ttk.Button(row, text=label, command=lambda m=matching: (selected.__setitem__(0, m), dialog.destroy())).pack(side="left", padx=3)
        dialog.wait_window()
        return selected[0]

    def _push_move(self, move: chess.Move, source: str) -> None:
        if move not in self.board.legal_moves:
            return
        san = self.board.san(move)
        self.board.push(move)
        self.last_move = move
        self.selected_square = None
        self.legal_targets.clear()
        self.best_move = None
        self.best_move_text = ""
        self.best_var.set("Melhor lance: —")
        self.eval_var.set("Avaliação: atualize com 'Melhor lance'.")
        self.move_var.set(f"Último lance: {san} ({chess.square_name(move.from_square)} → {chess.square_name(move.to_square)})")
        self._render_board()
        self._refresh_move_list()
        self.status_var.set(self._side_to_move_text())
        if source == "human" and self.mode_var.get() == "Jogar contra Stockfish" and not self.board.is_game_over(claim_draw=True):
            human_color = chess.WHITE if self.side_var.get() == "Brancas" else chess.BLACK
            if self.board.turn != human_color:
                self.root.after(150, self.play_engine_reply)

    def _refresh_move_list(self) -> None:
        temp = self.start_board.copy(stack=False)
        moves: list[str] = []
        for index, move in enumerate(self.board.move_stack):
            if temp.turn == chess.WHITE:
                moves.append(f"{temp.fullmove_number}. {temp.san(move)}")
            else:
                moves.append(temp.san(move))
            temp.push(move)
        output = "  ".join(moves) if moves else "Nenhum lance ainda."
        self.moves_text.configure(state="normal")
        self.moves_text.delete("1.0", "end")
        self.moves_text.insert("1.0", output)
        self.moves_text.configure(state="disabled")

    def _engine_color_turn(self) -> bool:
        if self.mode_var.get() != "Jogar contra Stockfish":
            return False
        human_color = chess.WHITE if self.side_var.get() == "Brancas" else chess.BLACK
        return self.board.turn != human_color

    def _ensure_engine_path(self) -> Path | None:
        if self.engine_path and self.engine_path.is_file():
            return self.engine_path
        return None

    def choose_engine(self) -> None:
        filename = filedialog.askopenfilename(
            title="Selecione o executável do Stockfish",
            filetypes=(("Stockfish / executável", "*.exe"), ("Todos os arquivos", "*.*")),
        )
        if not filename:
            return
        path = Path(filename)
        try:
            # Verify the selected file speaks UCI before keeping it.
            test_engine = chess.engine.SimpleEngine.popen_uci(str(path), timeout=8)
            test_engine.quit()
        except Exception as exc:
            messagebox.showerror("Stockfish inválido", f"Não consegui iniciar o motor escolhido.\n\nDetalhes: {exc}")
            return
        self._shutdown_engine()
        self.engine_path = path
        self.status_var.set(f"Stockfish selecionado: {path.name}")

    def _get_engine(self) -> chess.engine.SimpleEngine:
        path = self._ensure_engine_path()
        if path is None:
            raise FileNotFoundError("Selecione o executável do Stockfish para usar a análise.")
        if self.engine is None:
            self.engine = chess.engine.SimpleEngine.popen_uci(str(path), timeout=15)
            try:
                self.engine.configure({"Threads": max(1, min(4, os.cpu_count() or 1))})
            except (chess.engine.EngineError, chess.engine.EngineTerminatedError):
                pass
        return self.engine

    def analyse_position(self) -> None:
        if self.busy:
            return
        if self.board.is_game_over(claim_draw=True):
            self.status_var.set("A partida terminou; não há lance legal para jogar.")
            return
        try:
            depth = max(8, min(30, int(self.depth_var.get())))
        except (ValueError, tk.TclError):
            depth = 12
            self.depth_var.set(depth)
        self._start_worker("analysis", depth)

    def play_best_move(self) -> None:
        if self.busy or self.board.is_game_over(claim_draw=True):
            return
        try:
            depth = max(8, min(30, int(self.depth_var.get())))
        except (ValueError, tk.TclError):
            depth = 12
            self.depth_var.set(depth)
        self._start_worker("play_best", depth)

    def play_engine_reply(self) -> None:
        if self.busy or self.board.is_game_over(claim_draw=True) or not self._engine_color_turn():
            return
        try:
            depth = max(8, min(30, int(self.depth_var.get())))
        except (ValueError, tk.TclError):
            depth = 12
            self.depth_var.set(depth)
        self._start_worker("engine_move", depth)

    def _start_worker(self, kind: str, depth: int) -> None:
        if not self.engine_path or not self.engine_path.is_file():
            self.choose_engine()
            if not self.engine_path or not self.engine_path.is_file():
                self.status_var.set("Análise cancelada: nenhum Stockfish foi selecionado.")
                return
        self.busy = True
        self._set_controls_busy(True)
        self.request_id += 1
        token = self.request_id
        board_snapshot = self.board.copy(stack=True)
        fen_snapshot = self.board.fen()
        self.status_var.set("Stockfish está calculando…")

        def worker() -> None:
            try:
                engine = self._get_engine()
                if kind in ("engine_move", "play_best"):
                    result = engine.play(board_snapshot, chess.engine.Limit(depth=depth))
                    payload = {"move": result.move, "depth": depth}
                elif kind == "bestmove":
                    info = engine.analyse(board_snapshot, chess.engine.Limit(depth=depth))
                    payload = {"info": info, "depth": depth}
                else:
                    infos = engine.analyse(board_snapshot, chess.engine.Limit(depth=depth), multipv=3)
                    payload = {"infos": infos, "depth": depth}
                self.root.after(0, lambda: self._worker_success(token, kind, fen_snapshot, payload))
            except Exception as exc:
                self.root.after(0, lambda message=str(exc): self._worker_error(token, message))

        threading.Thread(target=worker, name="StockfishWorker", daemon=True).start()

    def _worker_success(self, token: int, kind: str, fen_snapshot: str, payload: dict) -> None:
        if token != self.request_id:
            return
        self.busy = False
        self._set_controls_busy(False)
        if self.board.fen() != fen_snapshot:
            self.status_var.set("A posição mudou durante a análise. Execute a análise novamente.")
            return
        if kind in ("engine_move", "play_best"):
            move = payload.get("move")
            if move is None or move not in self.board.legal_moves:
                self.status_var.set("Stockfish não retornou um lance legal nesta posição.")
                return
            san = self.board.san(move)
            self._push_move(move, source="engine" if kind == "engine_move" else "bestmove")
            prefix = "Stockfish jogou" if kind == "engine_move" else "Melhor lance executado"
            self.status_var.set(f"{prefix} {san}. {self._side_to_move_text()}")
            return
        if kind == "bestmove":
            info = payload["info"]
            move = info.get("pv", [None])[0]
            if move is None:
                self.status_var.set("O motor não encontrou um lance.")
                return
            self.best_move = move
            self.best_move_text = self.board.san(move)
            score = info.get("score")
            score_text = self._format_score(score)
            self.eval_var.set(f"Avaliação (perspectiva das brancas): {score_text}")
            self.best_var.set(f"Melhor lance: {self.best_move_text}  |  UCI: {move.uci()}")
            self._set_analysis_text(self._format_line(info, 1, self.board))
            self._render_board()
            self.status_var.set(f"Análise concluída em profundidade {payload['depth']}.")
            return
        lines = payload.get("infos", [])
        if isinstance(lines, dict):
            lines = [lines]
        if not lines:
            self.status_var.set("O motor não retornou linhas de análise.")
            return
        top = lines[0]
        best = top.get("pv", [None])[0]
        if best is not None:
            self.best_move = best
            self.best_move_text = self.board.san(best)
            self.best_var.set(f"Melhor lance: {self.best_move_text}  |  UCI: {best.uci()}")
        self.eval_var.set(f"Avaliação (perspectiva das brancas): {self._format_score(top.get('score'))}")
        self._set_analysis_text("\n\n".join(self._format_line(info, index + 1, self.board) for index, info in enumerate(lines)))
        self._render_board()
        self.status_var.set(f"Análise concluída em profundidade {payload['depth']} — {self._side_to_move_text()}")

    def _worker_error(self, token: int, message: str) -> None:
        if token != self.request_id:
            return
        self.busy = False
        self._set_controls_busy(False)
        self.status_var.set("Falha ao executar o Stockfish.")
        messagebox.showerror(
            "Erro no motor de xadrez",
            "Não consegui executar/analisar a posição com o Stockfish.\n\n"
            f"Detalhes: {message}\n\n"
            "Confirme se você selecionou o executável oficial compatível com o seu Windows.",
        )

    @staticmethod
    def _format_score(score) -> str:
        if score is None:
            return "indisponível"
        pov = score.pov(chess.WHITE)
        mate = pov.mate()
        if mate is not None:
            return f"mate em {mate}" if mate > 0 else f"mate contra em {abs(mate)}"
        cp = pov.score()
        if cp is None:
            return "indisponível"
        pawns = cp / 100.0
        return f"{pawns:+.2f}"

    @staticmethod
    def _format_line(info: dict, number: int, root_board: chess.Board) -> str:
        pv = info.get("pv", [])
        if not pv:
            return f"{number}. (sem variante)"
        temp = root_board.copy(stack=False)
        san_moves: list[str] = []
        for move in pv[:12]:
            if move not in temp.legal_moves:
                break
            san_moves.append(f"{temp.fullmove_number}." if temp.turn == chess.WHITE else "")
            san_moves.append(temp.san(move))
            temp.push(move)
        san_line = " ".join(item for item in san_moves if item)
        score = ChessBestMoveApp._format_score(info.get("score"))
        depth = info.get("depth", "?")
        return f"{number}. Avaliação {score} | profundidade {depth}\n   {san_line}"

    def new_game(self) -> None:
        if self.busy:
            return
        self.request_id += 1
        self.busy = False
        self._set_controls_busy(False)
        self.board = chess.Board()
        self.start_board = self.board.copy(stack=False)
        self.selected_square = None
        self.legal_targets.clear()
        self.last_move = None
        self.best_move = None
        self.best_var.set("Melhor lance: —")
        self.eval_var.set("Avaliação: —")
        self._set_analysis_text("Clique em 'Melhor lance' para analisar a posição atual.\n")
        self.move_var.set("Nenhum lance ainda.")
        self._render_board()
        self._refresh_move_list()
        self.status_var.set("Nova partida. " + self._side_to_move_text())
        if self.mode_var.get() == "Jogar contra Stockfish" and self.side_var.get() == "Pretas":
            self.root.after(200, self.play_engine_reply)

    def undo_move(self) -> None:
        if self.busy:
            return
        if not self.board.move_stack:
            self.status_var.set("Ainda não há lances para desfazer.")
            return
        count = 2 if self.mode_var.get() == "Jogar contra Stockfish" and len(self.board.move_stack) >= 2 else 1
        for _ in range(count):
            if self.board.move_stack:
                self.board.pop()
        self.last_move = self.board.move_stack[-1] if self.board.move_stack else None
        self.selected_square = None
        self.legal_targets.clear()
        self.best_move = None
        self.best_var.set("Melhor lance: —")
        self.eval_var.set("Avaliação: —")
        self._render_board()
        self._refresh_move_list()
        self.status_var.set("Lance(s) desfeito(s). " + self._side_to_move_text())
        if self._engine_color_turn():
            self.root.after(150, self.play_engine_reply)

    def load_fen(self) -> None:
        fen = simpledialog.askstring("Abrir posição FEN", "Cole a FEN da posição:", parent=self.root)
        if not fen:
            return
        try:
            new_board = chess.Board(fen.strip())
            if not new_board.is_valid():
                raise ValueError("A posição é inválida segundo as regras do xadrez.")
        except Exception as exc:
            messagebox.showerror("FEN inválida", f"Não consegui carregar esta posição.\n\n{exc}")
            return
        self.request_id += 1
        self.busy = False
        self._set_controls_busy(False)
        self.board = new_board
        self.start_board = self.board.copy(stack=False)
        self.last_move = None
        self.selected_square = None
        self.legal_targets.clear()
        self.best_move = None
        self.best_var.set("Melhor lance: —")
        self.eval_var.set("Avaliação: —")
        self._set_analysis_text("Posição carregada. Clique em 'Melhor lance' para analisar.\n")
        self.move_var.set("Posição carregada via FEN; histórico anterior não incluído.")
        self._render_board()
        self._refresh_move_list()
        self.status_var.set("FEN carregada. " + self._side_to_move_text())

    def export_pgn(self) -> None:
        filename = filedialog.asksaveasfilename(
            title="Exportar partida como PGN", defaultextension=".pgn",
            filetypes=(("Partida de xadrez PGN", "*.pgn"),),
        )
        if not filename:
            return
        game = chess.pgn.Game()
        game.setup(self.start_board)
        node = game
        replay = self.start_board.copy(stack=False)
        for move in self.board.move_stack:
            node = node.add_variation(move)
            replay.push(move)
        game.headers["Event"] = "ChessBestMove game"
        game.headers["Site"] = "Local"
        game.headers["Date"] = "????.??.??"
        game.headers["White"] = "Player / White"
        game.headers["Black"] = "Player / Black"
        game.headers["Result"] = self.board.result(claim_draw=True)
        try:
            with open(filename, "w", encoding="utf-8") as file:
                print(game, file=file, end="\n", flush=True)
            self.status_var.set(f"Partida exportada: {Path(filename).name}")
        except OSError as exc:
            messagebox.showerror("Erro ao exportar", str(exc))

    def _mode_changed(self, _event=None) -> None:
        self.new_game()

    def _side_changed(self, _event=None) -> None:
        if self.mode_var.get() == "Jogar contra Stockfish":
            self.new_game()

    def _set_controls_busy(self, busy: bool) -> None:
        button_state = "disabled" if busy else "normal"
        combo_state = "disabled" if busy else "readonly"
        for button in getattr(self, "action_buttons", []):
            button.configure(state=button_state)
        if hasattr(self, "mode_combo"):
            self.mode_combo.configure(state=combo_state)
        if hasattr(self, "side_combo"):
            self.side_combo.configure(state=combo_state)
        if hasattr(self, "depth_spin"):
            self.depth_spin.configure(state=button_state)

    def _shutdown_engine(self) -> None:
        engine, self.engine = self.engine, None
        if engine is not None:
            try:
                engine.quit()
            except Exception:
                try:
                    engine.close()
                except Exception:
                    pass

    def _on_close(self) -> None:
        self.request_id += 1
        self._shutdown_engine()
        self.root.destroy()


def main() -> None:
    root = tk.Tk()
    ChessBestMoveApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
