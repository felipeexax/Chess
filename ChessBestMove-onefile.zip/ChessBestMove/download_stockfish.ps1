$ErrorActionPreference = 'Stop'

$engineDir = Join-Path $PSScriptRoot 'engine'
$tempDir = Join-Path ([System.IO.Path]::GetTempPath()) 'ChessBestMove-Stockfish'
$zipPath = Join-Path $tempDir 'stockfish-windows-x86-64-universal.zip'
$extractDir = Join-Path $tempDir 'extracted'
$downloadUrl = 'https://github.com/official-stockfish/Stockfish/releases/latest/download/stockfish-windows-x86-64-universal.zip'

try {
    if (Test-Path $tempDir) {
        Remove-Item $tempDir -Recurse -Force
    }
    New-Item -ItemType Directory -Force -Path $tempDir, $extractDir, $engineDir | Out-Null

    Write-Host 'Baixando Stockfish universal oficial para Windows x86-64...' -ForegroundColor Cyan
    Invoke-WebRequest -Uri $downloadUrl -OutFile $zipPath
    Expand-Archive -Path $zipPath -DestinationPath $extractDir -Force

    $engineExe = Get-ChildItem -Path $extractDir -Recurse -File -Filter '*.exe' |
        Where-Object { $_.Name -match 'stockfish' } |
        Select-Object -First 1

    if (-not $engineExe) {
        throw 'Não encontrei um executável Stockfish dentro do ZIP baixado.'
    }

    # Preserve companion files (including .nnue network files) beside the executable.
    Get-ChildItem -Path $extractDir -Recurse -File | ForEach-Object {
        if ($_.FullName -eq $engineExe.FullName) {
            Copy-Item -Path $_.FullName -Destination (Join-Path $engineDir 'stockfish.exe') -Force
        }
        elseif ($_.Extension -eq '.nnue') {
            Copy-Item -Path $_.FullName -Destination (Join-Path $engineDir $_.Name) -Force
        }
    }

    if (-not (Test-Path (Join-Path $engineDir 'stockfish.exe'))) {
        throw 'O arquivo stockfish.exe não foi criado.'
    }

    Write-Host ''
    Write-Host 'Stockfish instalado em:' -ForegroundColor Green
    Write-Host (Join-Path $engineDir 'stockfish.exe')
    Write-Host 'Agora execute python main.py ou compile o aplicativo. Mantenha os arquivos .nnue na mesma pasta.'
}
catch {
    Write-Error "Falha ao baixar/instalar Stockfish: $($_.Exception.Message)"
    exit 1
}
finally {
    if (Test-Path $tempDir) {
        Remove-Item $tempDir -Recurse -Force -ErrorAction SilentlyContinue
    }
}
