Coloque aqui o motor Stockfish para Windows.

Você pode executar `..\download_stockfish.ps1` no PowerShell para baixar a versão universal oficial e colocar o executável em `stockfish.exe`. Se o ZIP incluir arquivos `.nnue`, mantenha-os junto do executável.
