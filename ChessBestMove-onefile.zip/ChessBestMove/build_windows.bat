@echo off
setlocal
cd /d "%~dp0"
echo ================================================
echo   ChessBestMove - compilador para Windows
 echo ================================================
py -3 -m pip install --upgrade pip
if errorlevel 1 goto :error
py -3 -m pip install -r requirements.txt pyinstaller
if errorlevel 1 goto :error
py -3 -m PyInstaller --noconfirm --clean --windowed --onefile --name ChessBestMove --collect-all chess main.py
if errorlevel 1 goto :error
if not exist "dist\ChessBestMove\engine" mkdir "dist\ChessBestMove\engine"
if exist "engine\stockfish.exe" xcopy "engine\*" "dist\ChessBestMove\engine\" /E /I /Y >nul
echo.
echo Build concluido: %CD%\dist\ChessBestMove.exe
echo Coloque stockfish.exe em dist\ChessBestMove\engine\ ou selecione-o no primeiro uso.
echo.
pause
exit /b 0
:error
echo.
echo A compilacao falhou. Confira se Python 3.11 ou 3.12 de 64 bits esta instalado e disponivel no comando py.
pause
exit /b 1
